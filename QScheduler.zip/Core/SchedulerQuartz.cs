﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Core.JobParams;
using Core.Jobs;
using Quartz;
using Quartz.Impl;
using Quartz.Impl.Matchers;

namespace Core
{
	public class SchedulerQuartz
	{
		private readonly IScheduler _Scheduler;
		
		public SchedulerQuartz()
		{
			ISchedulerFactory sf = new StdSchedulerFactory();
			_Scheduler = sf.GetScheduler();						
			_Scheduler.Start();
		}
		
		public List<string> GetTriggers()
		{
			var keys = _Scheduler.GetTriggerKeys(GroupMatcher<TriggerKey>.AnyGroup());

			var ret = new List<string>();
			foreach (var triggerKey in keys)
			{
				var tr = _Scheduler.GetTrigger(triggerKey);
				var state = _Scheduler.GetTriggerState(triggerKey);								
				ret.Add($" {triggerKey.Name.PadRight(20)}State: {state}");
			}

			return ret;
		}


		public void Run()
		{
			try
			{
				Logger.Instance.LogInfo("Inicializando Quartz...");				

				Random r = new Random();
				Thread.Sleep(r.Next(100) * 100);

				var paramConfig = new RelatorioOrdensParam
				{
					Name = "RelatorioClienteX",
					Enabled = true,
					IntervalSeconds = 10,
					ParamId = 123
				};
				
				SchedulerConfig sm = new SchedulerConfig();
				sm.CreateRelatorioOrdensJob(_Scheduler, paramConfig);

				Logger.Instance.LogInfo("Incializacao Quartz concluida!");
			}
			catch (SchedulerException se)
			{
				Logger.Instance.LogInfo(se.Message);
				Console.WriteLine(se);
				throw;
			}
		}


		

		//private void RegisterSchedule(IScheduler scheduler, IJobDetail job, ITrigger trigger)
		//{
		//	////-// Registrando Jobs	//-//
		//	////-// job Email	//-//
		//	//IJobDetail jDummyEnviarEmail = CreateJobDetail<JobDummyEnviarEmail>("EnviarEmail", SchedulerConstants.DefaultGroup);
		//	//ITrigger tDummyEnviarEmail = CreateTrigger(jDummyEnviarEmail, 2, x => x.WithIntervalInSeconds(5).RepeatForever());
		//	//RegisterSchedule(_Scheduler, jDummyEnviarEmail, tDummyEnviarEmail);

		//	//////-// job Twittada	//-//
		//	//IJobDetail jTweet = CreateJobDetail<JobDummyTwittada>("ExecutarTwitter", SchedulerConstants.DefaultGroup);
		//	//ITrigger tTweet = CreateTrigger(jTweet, 3, x => x.WithIntervalInSeconds(7).RepeatForever());
		//	//RegisterSchedule(_Scheduler, jTweet, tTweet);

		//	//if (!scheduler.GetTriggersOfJob(jobKey).Any())
		//	//{
		//	scheduler.ScheduleJob(job, new Quartz.Collection.HashSet<ITrigger>() { trigger }, true);
		//	Logger.Instance.LogInfo($"Setting Job [{job.Key.Group}.{job.Key.Name}] ");
		//	//}

		//}

	}
}
