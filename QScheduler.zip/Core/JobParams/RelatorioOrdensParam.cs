﻿namespace Core.JobParams
{	
	public class RelatorioOrdensParam: QuartzParameters
	{
		public int ParamId { get; set; }
	}
}
