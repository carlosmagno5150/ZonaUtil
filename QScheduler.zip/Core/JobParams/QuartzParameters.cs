using System;

namespace Core.JobParams
{
	public abstract class QuartzParameters
	{
		public int Id { get; set; }
		public string Name { get; set; }		
		public Boolean Enabled { get; set; }
		public int IntervalSeconds { get; set; }
	}
}