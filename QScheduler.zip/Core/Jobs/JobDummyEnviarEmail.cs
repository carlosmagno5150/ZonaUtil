﻿using System;
using Newtonsoft.Json;
using Quartz;

namespace Core.Jobs
{
	public class JobDummyEnviarEmail: IJob
	{
		public void Execute(IJobExecutionContext context)
		{			
			JobDataMap dataMap = context.JobDetail.JobDataMap;
			var jobSays = dataMap.GetString("parameters");

			//var teste = JsonConvert.DeserializeObject<TesteParam>(jobSays);

			//Console.WriteLine($"Envie email Koreano maluco quer flango flito - {teste.Name}");
			Logger.Instance.LogInfo($"Envie email Koreano maluco quer flango flito - {jobSays}");
		}
	}
}