﻿using System;
using System.Threading;
using Core;

namespace ConsoleTest
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Iniciando..");
			var q = new SchedulerQuartz();

			Console.WriteLine("Listando Agendamentos:");

			var trgs = q.GetTriggers();
			foreach (var t in trgs)
			{
				Console.WriteLine(t);
			}

			Console.WriteLine("");

			q.Run();

			while (true)
			{
				Thread.Sleep(TimeSpan.FromSeconds(60));
			}
		}
	}
}
