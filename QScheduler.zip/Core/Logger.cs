﻿using System;
using Common.Logging;

namespace Core
{

	public static class QSchedulerConst
	{
		public const string DefaultGroup = "DefaultGroup";
	}

	public class Logger
	{
		private static Logger _instance;

		public ILog Log { get; }

		private Logger()
		{
			//Log = LogManager.GetLogger("LogQuartz"); 			
		}

		public static Logger Instance => _instance ?? (_instance = new Logger());

		public void LogInfo(string msg)
		{
			//Log.Info(msg);
			Console.WriteLine(msg);
		}
	}
}