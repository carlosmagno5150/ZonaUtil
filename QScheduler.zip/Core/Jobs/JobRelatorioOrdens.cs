﻿using Core.JobParams;
using Newtonsoft.Json;
using Quartz;

namespace Core.Jobs
{
	public class JobRelatorioOrdens: IJob
	{
		public void Execute(IJobExecutionContext context)
		{
			JobDataMap dataMap = context.JobDetail.JobDataMap;
			var parameter = dataMap.GetString("parameters");
			var param = JsonConvert.DeserializeObject<RelatorioOrdensParam>(parameter);
			
			Logger.Instance.LogInfo($"Name: {param.Name}  Enabled: {param.Enabled}  Interval: {param.IntervalSeconds}  ParamId: {param.ParamId}");			
		}
	}
}