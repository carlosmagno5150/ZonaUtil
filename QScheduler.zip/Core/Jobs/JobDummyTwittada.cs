﻿using System;
using Quartz;

namespace Core.Jobs
{
    public class JobDummyTwittada: IJob	
	{
	    public void Execute(IJobExecutionContext context)
	    {
		    Console.WriteLine("Twittando: Americano gordo de Peruca");
				Logger.Instance.LogInfo("Twittando: Americano gordo de Peruca");
		}
	}
}
