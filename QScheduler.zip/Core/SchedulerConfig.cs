﻿using System;
using Core.JobParams;
using Core.Jobs;
using Newtonsoft.Json;
using Quartz;

namespace Core
{
	public  class SchedulerConfig
	{
		public void CreateRelatorioOrdensJob(IScheduler scheduler, RelatorioOrdensParam parameter)
		{
			var job = CreateJobDetail<JobRelatorioOrdens>(parameter);
			var trigger = CreateTrigger(job, 3, x => x.WithIntervalInSeconds(parameter.IntervalSeconds).RepeatForever());

			RegisterSchedule(scheduler, job, trigger);
		}
		

		private ITrigger CreateTrigger(IJobDetail job, int secondsToStart, Action<SimpleScheduleBuilder> interval)
		{
			return TriggerBuilder.Create()
					.WithIdentity(job.Key.Name, job.Key.Group)
					.StartAt(DateTime.Now.AddSeconds(secondsToStart))
					.WithSimpleSchedule(interval)
					.ForJob(job)
					.Build();
		}

		private IJobDetail CreateJobDetail<T>(QuartzParameters parameter) where T : IJob
		{
			return JobBuilder.Create<T>()
				.WithIdentity(new JobKey(parameter.Name, SchedulerConstants.DefaultGroup))
				.UsingJobData("parameters", JsonConvert.SerializeObject(parameter))
				.StoreDurably(true)
				.Build();
		}

		private void RegisterSchedule(IScheduler scheduler, IJobDetail job, ITrigger trigger)
		{			
			scheduler.ScheduleJob(job, new Quartz.Collection.HashSet<ITrigger>() { trigger }, true);
			Logger.Instance.LogInfo($"Setting Job [{job.Key.Group}.{job.Key.Name}] ");
		}
	}


}
